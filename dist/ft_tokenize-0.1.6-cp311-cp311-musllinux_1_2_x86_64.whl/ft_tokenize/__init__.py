#ft_tokenize/__init__.py
from .ft_tokenize import *
